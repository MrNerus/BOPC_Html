Help_Toggle = 0;
var Setup = "****";
var Punchline = "***";
var captured;
const wait=ms=>new Promise(resolve => setTimeout(resolve, ms));
Another_One();

// =====================


function Click_Info(){
    if (Help_Toggle == 0) {
        Show_Info();
    }
    else if (Help_Toggle == 1) {
        Hide_Info();
    }
}

function Show_Info(){
    Help_Toggle = 1;
    console.log(Help_Toggle);
    document.getElementById("Help_Box").style.height = "35px";
}

function Hide_Info(){
    Help_Toggle = 0;
    document.getElementById("Help_Box").style.height = "0px";
}


// ====================

function Set_Joke(data){
    console.log(data);
    captured = data;
    console.log(captured);

    Setup = captured["setup"];
    Punchline = captured["punchline"];
    console.log(Setup);
    console.log(Punchline);
}
function Another_One() {
    document.getElementById("Buffer").style.height = "30px";

    let Url = 'https://official-joke-api.appspot.com/random_joke';

    fetch(Url)
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        Set_Joke(data);
    })
    .catch(function(err) {
        console.log('error: ' + err);
    });
    wait(4*1000).then(() => console.log("waited for 2 seconds")); 
    
    console.log(Setup);
    console.log(Punchline);
    Update_Setup();
    document.getElementById("Buffer").style.height = "0px";
}

function Update_Setup() {
    document.getElementById("Setup").innerHTML = Setup;
}
function Update_Punchine() {
    document.getElementById("Punchline").innerHTML = Punchline;
}